<?php
	echo "hi sunil how r u?";
?>