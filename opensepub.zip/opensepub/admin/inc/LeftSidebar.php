     <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
 
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="active"><a href="customer_management.html"><span>Customer Management</span></a></li>
		<li><a href="tutorial_usage_history.html"><span>Tutorial Usage History</span></a></li>
		<li><a href="product_management.html"><span>Product Management</span></a></li>
        <li class=" treeview">
          <a href="#">
             <span>Service Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="contract_history_management.html"><i class="fa fa-circle"></i> Contract History Management</a></li>
            <li><a href="#"><i class="fa fa-circle"></i> Manage Usage History</a></li>
          </ul>
        </li>
        <li class=" treeview">
          <a href="#">
             <span>Notice</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="notice.html"><i class="fa fa-circle"></i> Notice</a></li>
            <li><a href="faq.html"><i class="fa fa-circle"></i> FAQ</a></li>
          </ul>
        </li>		
      </ul>
    </section>
    <!-- /.sidebar -->
 